package com.Util;

/**
 * Created by felixamoruwa on 5/31/15.
 */
public interface ScoredStudentStatsInt {

    //void findLowScores(ScoredStudent[] stu);

    //void findHighScores(ScoredStudent[] stu);

    //void findAvgScores(ScoredStudent[] stu);

}
