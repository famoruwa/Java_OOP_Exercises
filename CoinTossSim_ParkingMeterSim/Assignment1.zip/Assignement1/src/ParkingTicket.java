/**
 * Created by felixamoruwa on 5/23/15.
 */
public class ParkingTicket {

    //Report the fine: $25 for the first hour plus $10 for each additional hour
    //Report the name and badge number of the police officer issuing the ticket

    public ParkingTicket(String make, String model, String license, String color, String badge, String name, double fine) {

    }

}
